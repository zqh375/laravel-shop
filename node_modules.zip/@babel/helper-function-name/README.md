# @babel/helper-function-name

> Helper function to change the property 'name' of every function

See our website [@babel/helper-function-name](https://babeljs.io/docs/en/babel-helper-function-name) for more information.

## Install

Using npm:

```sh
npm install --save @babel/helper-function-name
```

or using yarn:

```sh
yarn add @babel/helper-function-name
```
