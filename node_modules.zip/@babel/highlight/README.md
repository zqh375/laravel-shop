# @babel/highlight

> Syntax highlight JavaScript strings for output in terminals.

See our website [@babel/highlight](https://babeljs.io/docs/en/babel-highlight) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/highlight
```

or using yarn:

```sh
yarn add @babel/highlight --dev
```
